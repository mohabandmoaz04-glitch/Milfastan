# Milfastan

نظام معالج ورافع ملفات مبني بـ Next.js و Tailwind CSS.

## التثبيت

1. ثبت Node.js و npm.
2. نفذ:
   ```bash
   npm install
   ```

3. أنشئ ملف `.env.local` أو استخدم `.env.example` مع قيمة `DATABASE_URL` الصحيحة.

## إعداد قاعدة البيانات

استخدم `schema.sql` لإنشاء الجدول:

```sql
CREATE TABLE IF NOT EXISTS payment_requests (
  id SERIAL PRIMARY KEY,
  ip_address TEXT NOT NULL,
  user_phone_or_receipt TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
```

## تشغيل المشروع

```bash
npm run dev
```

## كيف يعمل المشروع

- كل IP يحصل على ملفين مجانيين.
- بعد تجاوز الملفين يظهر مودال الاشتراك.
- يمكن إدخال رقم المحفظة أو إيصال التحويل وسيتم حفظ الطلب في جدول `payment_requests` بحالة `pending`.
- يتم التحقق من اشتراك الـ IP بحالة `active` لتفعيل 3 معالجات يومية.
- معالجات الخطة المدفوعة تُعاد إلى الصفر يومياً عند منتصف الليل بتوقيت مصر.
