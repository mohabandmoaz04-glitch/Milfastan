import { NextRequest, NextResponse } from 'next/server';
import { pool } from '../../../lib/db';

function getClientIp(request: NextRequest) {
  return request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
}

export async function POST(request: NextRequest) {
  const ip = getClientIp(request);
  const body = await request.json().catch(() => null);

  if (!body || typeof body.user_phone_or_receipt !== 'string' || !body.user_phone_or_receipt.trim()) {
    return NextResponse.json({ error: 'الرجاء إدخال رقم المحفظة أو إيصال التحويل.' }, { status: 400 });
  }

  const text = 'INSERT INTO payment_requests (ip_address, user_phone_or_receipt, status) VALUES ($1, $2, $3) RETURNING id';
  const values = [ip, body.user_phone_or_receipt.trim(), 'pending'];

  try {
    await pool.query(text, values);
    return NextResponse.json({ message: 'سيتم تفعيل خطتك خلال 24 ساعة.' });
  } catch (error) {
    console.error('DB insert error:', error);
    return NextResponse.json({ error: 'حدث خطأ أثناء حفظ الطلب. حاول مرة أخرى.' }, { status: 500 });
  }
}
