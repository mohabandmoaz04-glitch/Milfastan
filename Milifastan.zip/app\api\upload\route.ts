import { NextRequest, NextResponse } from 'next/server';
import { pool } from '../../../lib/db';

const freeUploadsByIp = new Map<string, number>();
const paidUploadsByIp = new Map<string, { date: string; count: number }>();

function getCairoDateString() {
  const date = new Date();
  const options: Intl.DateTimeFormatOptions = { timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit', day: '2-digit' };
  const formatted = new Intl.DateTimeFormat('en-CA', options).format(date);
  return formatted;
}

function getClientIp(request: NextRequest) {
  return request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
}

export async function POST(request: NextRequest) {
  const ip = getClientIp(request);
  const formData = await request.formData();
  const file = formData.get('file');

  if (!file || typeof file === 'string') {
    return NextResponse.json({ error: 'لم يتم إرسال الملف.' }, { status: 400 });
  }

  const freeCount = freeUploadsByIp.get(ip) ?? 0;
  if (freeCount < 2) {
    freeUploadsByIp.set(ip, freeCount + 1);
    return NextResponse.json({ message: 'تمت معالجة الملف مجاناً. يمكنك رفع ملف واحد إضافي مجاناً.' });
  }

  const result = await pool.query('SELECT status FROM payment_requests WHERE ip_address = $1 ORDER BY created_at DESC LIMIT 1', [ip]);
  const activeRow = result.rows[0];
  const isActive = activeRow?.status === 'active';

  if (!isActive) {
    return NextResponse.json({ limitExceeded: true, error: 'تجاوزت الحد المجاني ويجب الاشتراك.' }, { status: 402 });
  }

  const today = getCairoDateString();
  const existing = paidUploadsByIp.get(ip);
  if (!existing || existing.date !== today) {
    paidUploadsByIp.set(ip, { date: today, count: 1 });
    return NextResponse.json({ message: 'تمت معالجة الملف ضمن خطة الاشتراك. المتبقي اليوم: 2 معالجات.' });
  }

  if (existing.count >= 3) {
    return NextResponse.json({ error: 'لقد استنفدت الـ 3 معالجات لهذا اليوم. سيتم إعادة الضبط الساعة 12 منتصف الليل بتوقيت مصر.' }, { status: 429 });
  }

  paidUploadsByIp.set(ip, { date: today, count: existing.count + 1 });
  return NextResponse.json({ message: 'تمت معالجة الملف ضمن خطة الاشتراك. استمر في الاستخدام اليومي.' });
}
