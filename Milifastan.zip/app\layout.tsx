import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = {
  title: 'Milfastan - نظام معالجة الملفات',
  description: 'نظام رفع ومعالجة الملفات مع خطة اشتراك يومية ونظام دفع يدوي.'
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
