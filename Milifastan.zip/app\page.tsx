'use client';

import { useEffect, useState } from 'react';
import Header from '../components/Header';
import UploadPanel from '../components/UploadPanel';
import SubscribeModal from '../components/SubscribeModal';

export default function HomePage() {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    const saved = window.localStorage.getItem('milfastan-theme');
    if (saved === 'dark') {
      setTheme('dark');
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem('milfastan-theme', theme);
  }, [theme]);

  function toggleTheme() {
    setTheme((current) => (current === 'dark' ? 'light' : 'dark'));
  }

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <Header onSubscribe={() => setModalOpen(true)} theme={theme} toggleTheme={toggleTheme} />
      <section className="mx-auto flex max-w-7xl flex-col gap-10 px-6 py-12 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[0.95fr_0.85fr] lg:items-center">
          <div className="space-y-6">
            <p className="inline-flex rounded-full bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-700 dark:bg-blue-900/30 dark:text-blue-200">
              نظام رفع الملفات - Milfastan
            </p>
            <h1 className="text-4xl font-semibold leading-tight tracking-tight text-slate-950 dark:text-white sm:text-5xl">
              حل متكامل لمعالجة الملفات مع حدين مجاني ومدفوع
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-slate-600 dark:text-slate-300">
              ارفع ملفين مجاناً عبر IP واحد. عند تجاوز الحد تظهر لك نافذة الاشتراك السهلة، ويمكنك تقديم رقم المحفظة أو إيصال التحويل ليتم حفظ الطلب ومراجعته خلال 24 ساعة.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <button
                type="button"
                onClick={() => setModalOpen(true)}
                className="rounded-3xl bg-blue-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-blue-500"
              >
                ابدأ الاشتراك
              </button>
              <a href="#upload" className="rounded-3xl border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-900 transition hover:border-slate-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100">
                رفع ملف الآن
              </a>
            </div>
          </div>
          <div className="rounded-[2rem] bg-gradient-to-br from-blue-600 to-indigo-600 px-8 py-10 text-white shadow-2xl shadow-blue-600/20">
            <h2 className="text-3xl font-semibold">3 معالجات يومية</h2>
            <p className="mt-4 text-slate-100/90 leading-7">
              خطة مدفوعة تتيح لك تشغيل 3 عمليات معالجة يومياً. يتم إعادة العد في منتصف الليل بتوقيت مصر تلقائياً.
            </p>
            <div className="mt-8 grid gap-4 text-sm">
              <div className="rounded-3xl bg-white/10 p-5">
                <p className="font-semibold">الحد المجاني</p>
                <p className="mt-2 text-slate-200/90">ملفين مجانيين لكل IP فقط.</p>
              </div>
              <div className="rounded-3xl bg-white/10 p-5">
                <p className="font-semibold">خطة الاشتراك</p>
                <p className="mt-2 text-slate-200/90">3 معالجات يومية مع التحقق من IP وstatus active.</p>
              </div>
              <div className="rounded-3xl bg-white/10 p-5">
                <p className="font-semibold">دفع يدوي</p>
                <p className="mt-2 text-slate-200/90">أضف رقم المحفظة أو إيصال التحويل داخل النافذة المنبثقة.</p>
              </div>
            </div>
          </div>
        </div>

        <div id="upload">
          <UploadPanel onOpenSubscription={() => setModalOpen(true)} />
        </div>
      </section>

      <SubscribeModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </main>
  );
}
