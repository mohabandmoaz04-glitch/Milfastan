'use client';

import { useEffect } from 'react';

interface HeaderProps {
  onSubscribe: () => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

export default function Header({ onSubscribe, theme, toggleTheme }: HeaderProps) {
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      root.classList.remove('dark');
      document.body.classList.remove('dark');
    }
  }, [theme]);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/80 bg-white/90 backdrop-blur-xl dark:border-slate-700/80 dark:bg-slate-950/90">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-700 dark:text-slate-300">Milfastan</p>
          <h1 className="mt-1 text-xl font-semibold text-slate-950 dark:text-white">نظام معالجة وتحميل الملفات</h1>
        </div>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={toggleTheme}
            className="rounded-full border border-slate-300/90 bg-slate-100 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-200 dark:border-slate-600/90 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
          >
            {theme === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}
          </button>
          <button
            type="button"
            onClick={onSubscribe}
            className="rounded-full bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-500"
          >
            اشترك الآن
          </button>
        </div>
      </div>
    </header>
  );
}
