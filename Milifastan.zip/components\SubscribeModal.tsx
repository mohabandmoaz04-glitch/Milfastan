'use client';

import { useState, FormEvent } from 'react';

interface SubscribeModalProps {
  open: boolean;
  onClose: () => void;
}

export default function SubscribeModal({ open, onClose }: SubscribeModalProps) {
  const [input, setInput] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  if (!open) return null;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!input.trim()) {
      setMessage('الرجاء إدخال رقم المحفظة أو إيصال التحويل.');
      setStatus('error');
      return;
    }

    setStatus('sending');
    setMessage('جاري الإرسال...');

    try {
      const response = await fetch('/api/payment_requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ user_phone_or_receipt: input.trim() })
      });
      const data = await response.json();

      if (!response.ok) {
        setMessage(data.error || 'حدث خطأ أثناء الإرسال. حاول مرة أخرى.');
        setStatus('error');
        return;
      }

      setStatus('success');
      setMessage('سيتم تفعيل خطتك خلال 24 ساعة.');
      setInput('');
    } catch (error) {
      setStatus('error');
      setMessage('فشل الاتصال بالخادم. حاول لاحقاً.');
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card" onClick={(event) => event.stopPropagation()}>
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-blue-600 dark:text-blue-300">خطة الاشتراك</p>
            <h2 className="mt-3 text-2xl font-semibold text-slate-950 dark:text-white">ترقية الحساب</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full bg-slate-200 px-3 py-2 text-sm text-slate-700 hover:bg-slate-300 dark:bg-slate-700 dark:text-slate-100 dark:hover:bg-slate-600"
          >
            إغلاق
          </button>
        </div>

        <div className="mt-6 rounded-3xl bg-slate-50 p-4 text-sm text-slate-700 dark:bg-slate-800 dark:text-slate-200">
          <p>يمكنك ترقية خطتك مقابل 150 جنيه مصري تقريباً للحصول على 3 معالجات يومية.</p>
          <p className="mt-2 font-semibold">أدخل رقم المحفظة أو رقم إيصال التحويل وسيتم حفظ الطلب في قاعدة البيانات.</p>
        </div>

        <form className="mt-6 space-y-4" onSubmit={handleSubmit}>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">
            رقم المحفظة أو إيصال التحويل
            <input
              value={input}
              onChange={(event) => setInput(event.target.value)}
              className="mt-2 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-100 dark:focus:border-blue-400 dark:focus:ring-blue-500/20"
              placeholder="مثلاً 01234567890 أو رقم إيصال"
            />
          </label>

          <button
            type="submit"
            className="w-full rounded-2xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-500"
            disabled={status === 'sending'}
          >
            إرسال الطلب
          </button>
          {message ? (
            <p className={`mt-2 text-sm ${status === 'error' ? 'text-rose-500' : 'text-emerald-600'}`}>
              {message}
            </p>
          ) : null}
        </form>
      </div>
    </div>
  );
}
