'use client';

import { useState, ChangeEvent, FormEvent } from 'react';

interface UploadPanelProps {
  onOpenSubscription: () => void;
}

export default function UploadPanel({ onOpenSubscription }: UploadPanelProps) {
  const [fileName, setFileName] = useState('');
  const [message, setMessage] = useState('اختر ملفاً ثم اضغط رفع لمعالجته.');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedFile) {
      setMessage('الرجاء اختيار ملف أولاً.');
      setStatus('error');
      return;
    }

    setStatus('loading');
    setMessage('جاري معالجة الملف...');

    const formData = new FormData();
    formData.append('file', selectedFile);

    const response = await fetch('/api/upload', {
      method: 'POST',
      body: formData
    });
    const data = await response.json();

    if (!response.ok) {
      if (data.limitExceeded) {
        setStatus('error');
        setMessage('لقد تجاوزت حد الملفين المجانيين. الرجاء الاشتراك.');
        onOpenSubscription();
        return;
      }
      setStatus('error');
      setMessage(data.error || 'حدث خطأ أثناء المعالجة.');
      return;
    }

    setStatus('success');
    setMessage(data.message || 'تمت معالجة الملف بنجاح.');
    setFileName('');
    setSelectedFile(null);
  }

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0] ?? null;
    setSelectedFile(file);
    setFileName(file?.name ?? '');
    setStatus('idle');
    setMessage('جاهز للرفع.');
  }

  return (
    <section className="rounded-[2rem] border border-slate-200/90 bg-white/95 p-8 shadow-xl shadow-slate-200/40 dark:border-slate-700/90 dark:bg-slate-950/95 dark:shadow-none">
      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <span className="inline-flex rounded-full bg-blue-100 px-4 py-1 text-xs font-semibold uppercase tracking-[0.24em] text-blue-700 dark:bg-blue-900/50 dark:text-blue-200">
            2 ملفين مجانيين
          </span>
          <h2 className="mt-6 text-3xl font-semibold leading-tight text-slate-950 dark:text-white">ارفع ملفك واستفد من المعالجة الفورية</h2>
          <p className="mt-4 max-w-xl text-slate-600 dark:text-slate-300">
            يمكنك رفع ملفين مجاناً عبر IP واحد. بعد ذلك ستحتاج إلى الاشتراك لخطة مع 3 معالجات يومية تستعيد في منتصف الليل بتوقيت مصر.
          </p>
        </div>

        <div className="rounded-3xl bg-slate-50 p-6 dark:bg-slate-900">
          <form className="space-y-5" onSubmit={handleSubmit}>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-200">
              اختر ملف
              <input
                type="file"
                onChange={handleChange}
                className="mt-3 w-full rounded-3xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none file:mr-4 file:rounded-full file:border-0 file:bg-blue-600 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:bg-blue-500 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </label>
            {fileName ? <p className="text-sm text-slate-500 dark:text-slate-400">ملف مختار: {fileName}</p> : null}
            <button
              type="submit"
              className="w-full rounded-3xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-500"
            >
              رفع ومعالجة
            </button>
            <div className="rounded-3xl bg-slate-100 p-4 text-sm text-slate-700 dark:bg-slate-800 dark:text-slate-300">
              <p>{message}</p>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
