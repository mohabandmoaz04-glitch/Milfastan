import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: ['class'],
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          light: '#2563eb',
          dark: '#60a5fa'
        },
        surface: {
          light: '#f8fafc',
          dark: '#0f172a'
        }
      }
    }
  },
  plugins: []
};

export default config;
